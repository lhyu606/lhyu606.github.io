<?php


namespace app\lib\exception;

use think\exception\Handle;
use think\facade\Request;
use think\Log;
use Exception;

/*
 * 重写Handle的render方法，实现自定义异常消息
 */
class ApiHandleException extends Handle
{
    private $code;
    private $msg;
    private $errorCode;

    public function render(Exception $e)
    {
        if ($e instanceof ApiException)
        {
            $this->code = $e->code;
            $this->msg = $e->msg;
            $this->errorCode = $e->errorCode;
        } else {
            if(config('app_debug')){
                return parent::render($e);
            }

            $this->code = 500;
            $this->msg = '网络异常，请联系管理员！';
            $this->errorCode = 999;
            $this->recordErrorLog($e);
        }

        $result = [
            'msg'  => $this->msg,
            'error_code' => $this->errorCode,
            'request_url' => Request::url(),
        ];
        return json($result, $this->code);
    }

    /*
     * 将异常写入日志
     */
    private function recordErrorLog(Exception $e)
    {
        Log::init([
            'type'  =>  'File',
            'path'  =>  LOG_PATH,
            'level' => ['error']
        ]);
        Log::record($e->getMessage(),'error');
    }
}