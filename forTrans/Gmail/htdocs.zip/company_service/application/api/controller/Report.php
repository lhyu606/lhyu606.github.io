<?php
namespace app\api\controller;

use app\api\service\ReportService;
use app\api\validate\BaoBeiVaildate;
use think\facade\Request;

class Report extends BaseController {

    /**
     * 保存报备信息
     * @param Request $request
     */
    public function saveBaoBei(Request $request) {
        // (new BaoBeiVaildate())->requestCheck();
        $param = [];
        $param['baobeihao'] = $request::post('baobeihao');
        $param['date'] = $request::post('date');
        $param['shopName'] = $request::post('shopName');
        $param['uname'] = $request::post('uname');
        $param['baogaohao'] = $request::post('baogaohao');
        $param['zhushif'] = $request::post('zhushif');
        $param['zhushis'] = $request::post('zhushis');
        $param['yijian'] = $request::post('yijian');

        $res = ReportService::saveBaoBei($param);
        if (empty($res)) {
            $this->ok();
        }
        $this->ok($res);
    }
    /**
     * 修改报备信息
     * @param Request $request
     */
    public function editBaoBei(Request $request) {
        // (new BaoBeiVaildate())->requestCheck();
        $param = [];
        $param['id'] = $request::post('id');
        $param['baobeihao'] = $request::post('baobeihao');
        $param['date'] = $request::post('date');
        $param['shopName'] = $request::post('shopName');
        $param['uname'] = $request::post('uname');
        $param['baogaohao'] = $request::post('baogaohao');
        $param['zhushif'] = $request::post('zhushif');
        $param['zhushis'] = $request::post('zhushis');
        $param['yijian'] = $request::post('yijian');

        $res = ReportService::editBaoBei($param);
        if (empty($res)) {
            $this->ok();
        }
        $this->ok($res);
    }
    /**
     * 根据 id 获取报备信息
     * @param Request $request
     */
    public function getBaoBei(Request $request) {
        // (new BaoBeiVaildate())->requestCheck();
        $content = ReportService::getBaoBeiById($request::post('id'));
        if (empty($content)) {
            $this->ok();
        }
        $this->ok($content);
    }
    /**
     * 根据 id 获取报备信息
     * @param Request $request
     */
    public function getBaoBeiByPage(Request $request) {
        // (new BaoBeiVaildate())->requestCheck();
        $content = ReportService::getBaoBeiByPage($request::post('page'));
        if (empty($content)) {
            $this->ok();
        }
        $this->ok($content);
    }
    /**
     * 根据 id 删除报备信息
     * @param Request $request
     */
    public function deleteBaoBeiById(Request $request) {
        // (new BaoBeiVaildate())->requestCheck();
        $content = ReportService::deleteBaoBeiById($request::post('id'));
        if (empty($content)) {
            $this->ok();
        }
        $this->ok($content);
    }

    /**
     * 保存税务信息
     * @param Request $request
     */
    public function saveShuiWu(Request $request) {
        // (new ShuiWuVaildate())->requestCheck();
        $param = [];
        $param['source'] = $request::post('source');
        $param['wenShu'] = $request::post('wenShu');
        $param['naShuiId'] = $request::post('naShuiId');
        $param['naShuiName'] = $request::post('naShuiName');
        $param['stockStart'] = $request::post('stockStart');
        $param['stockEnd'] = $request::post('stockEnd');
        $param['naShuiDate'] = $request::post('naShuiDate');
        $param['totle'] = $request::post('totle');
        $param['totleBig'] = $request::post('totleBig');
        $param['taxItem'] = $request::post('taxItem');
        $param['taxPaid'] = $request::post('taxPaid');
        $param['taxReturn'] = $request::post('taxReturn');
        $param['taxPaidReturn'] = $request::post('taxPaidReturn');

        $res = ReportService::saveShuiWu($param);
        if (empty($res)) {
            $this->ok();
        }
        $this->ok($res);
    }

    /**
     * 保存税务信息
     * @param Request $request
     */
    public function editShuiWu(Request $request) {
        // (new ShuiWuVaildate())->requestCheck();
        $param = [];
        $param['id'] = $request::post('id');
        $param['source'] = $request::post('source');
        $param['wenShu'] = $request::post('wenShu');
        $param['naShuiId'] = $request::post('naShuiId');
        $param['naShuiName'] = $request::post('naShuiName');
        $param['stockStart'] = $request::post('stockStart');
        $param['stockEnd'] = $request::post('stockEnd');
        $param['naShuiDate'] = $request::post('naShuiDate');
        $param['totle'] = $request::post('totle');
        $param['totleBig'] = $request::post('totleBig');
        $param['taxItem'] = $request::post('taxItem');
        $param['taxPaid'] = $request::post('taxPaid');
        $param['taxReturn'] = $request::post('taxReturn');
        $param['taxPaidReturn'] = $request::post('taxPaidReturn');

        $res = ReportService::editShuiWu($param);
        if (empty($res)) {
            $this->ok();
        }
        $this->ok($res);
    }

    /**
     * 根据 id 获取税务信息
     * @param Request $request
     */
    public function getShuiWu(Request $request) {
        // (new ShuiWuVaildate())->requestCheck();
        $content = ReportService::getShuiWuById($request::post('id'));
        if (empty($content)) {
            $this->ok();
        }
        $this->ok($content);
    }

    /**
     * 根据 id 获取税务信息
     * @param Request $request
     */
    public function getShuiWuByPage(Request $request) {
        // (new BaoBeiVaildate())->requestCheck();
        $content = ReportService::getShuiWuByPage($request::post('page'));
        if (empty($content)) {
            $this->ok();
        }
        $this->ok($content);
    }
    /**
     * 根据 id 删除税务信息
     * @param Request $request
     */
    public function deleteShuiWuById(Request $request) {
        // (new BaoBeiVaildate())->requestCheck();
        $result = ReportService::deleteShuiWuById($request::post('id'));
        if (empty($result)) {
            $this->ok();
        }
        $this->ok($result);
    }
}