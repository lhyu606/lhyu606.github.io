<?php
namespace app\api\controller;

use app\api\service\CompanyExtendService;
use app\api\service\CompanyService;
use app\api\validate\HeadShopValidate;
use app\api\validate\RegionCodeVaildate;
use app\api\validate\ShopNameValidate;
use app\api\validate\ShopNoVaildate;
use think\facade\Request;
use think\facade\Cache;

class Company extends BaseController {

    /**
     *
     * 根据地区获取开通电子会员卡权限的商家
     * @param Request $request
     */
    public function getCompanyListOpenECardByRegionCode(Request $request) {
        (new RegionCodeVaildate())->requestCheck();
        $companyList = CompanyService::getCompanyListByRegionCode($request::get('regionCode'));
        if (empty($companyList)) {
            $this->ok();
        }
        $data = CompanyService::putCompany($companyList);
        $this->ok($data);
    }

    /**
     * 根据总店获取开通会员卡的商家
     *
     * @param Request $request
     */
    public function getCompanyListOpenECardByHeadShopNo(Request $request) {
        (new HeadShopValidate())->requestCheck();
        $companyList = CompanyService::getCompanyListByHeadShopNo($request::get('headShopNo'));
        if (empty($companyList)) {
            $this->ok();
        }
        $data = CompanyService::putCompany($companyList);
        $this->ok($data);
    }

    /**
     * 根据商家名获取开通会员卡的商家
     *
     * @param Request $request
     * @throws \app\lib\exception\ApiException
     */
    public function getCompanyListOpenECardByCompanyName(Request $request) {
        (new ShopNameValidate())->requestCheck();
        $companyList = CompanyService::getCompanyListByShopName($request::get('companyName'));
        if (empty($companyList)) {
            $this->ok();
        }
        $data = CompanyService::putCompany($companyList);
        $this->ok($data);

    }

    /**
     * 判断商家是否开通电子会员
     * @param Request $request
     * @throws \app\lib\exception\ApiException
     */
    public function isOpenEcard(Request $request) {
        (new ShopNoVaildate())->requestCheck();
        $isOpenEcard = CompanyService::isOpenEcard($request::get('shopNo'));
        $this->ok(array('isOpenEcard' => $isOpenEcard));

    }

    /**
     * @param Request $request
     * @return array|\PDOStatement|string|\think\Model|null
     * @throws \app\lib\exception\ApiException
     */
    public function getCompanyInfo(Request $request) {

        (new ShopNoVaildate())->requestCheck();
        $companyInfo = CompanyService::getCompanyInfo($request::get('shopNo'));
        $this->ok($companyInfo);
    }

    public function getCompanyExtend(Request $request) {
        (new ShopNoVaildate())->requestCheck();

        $extendInfo = CompanyExtendService::getExtendByShopNo($request::get('shopNo'));

        $this->ok($extendInfo);
    }

    public function test() {
        echo 1;
        Cache::set('key', 'test');
        echo Cache::get('key');

//        print_r(Cache::get('sync_cache_access_token:manageclient:36:8s320e48a3sfsfd32047a9fcdadbfs'));

        print_r(Cache::get('company_extend_info_48'));

    }


}