<?php
namespace app\api\controller;

use app\api\service\QrService;
use app\api\validate\QrVaildate;
use think\facade\Request;

class Qr extends BaseController {

    /**
     * 
     * @param Request $request
     */
    public function saveQrContent(Request $request) {
        // (new QrVaildate())->requestCheck();
        $param = [];
        $param['baobeihao'] = $request::post('baobeihao');
        $param['date'] = $request::post('date');
        $param['shopName'] = $request::post('shopName');
        $param['uname'] = $request::post('uname');
        $param['baogaohao'] = $request::post('baogaohao');
        $param['zhushif'] = $request::post('zhushif');
        $param['zhushis'] = $request::post('zhushis');
        $param['yijian'] = $request::post('yijian');

        $res = QrService::saveQrContent($param);
        if (empty($res)) {
            $this->ok();
        }
        $this->ok($res);
    }

    /**
     * 
     * @param Request $request
     */
    public function getQrContent(Request $request) {
        // (new QrVaildate())->requestCheck();
        $content = QrService::getQrContentById($request::post('id'));
        if (empty($content)) {
            $this->ok();
        }
        $this->ok($content);
    }
}