<?php
namespace app\api\controller;

use app\api\service\WechatPubInfoService;
use app\api\validate\ShopNoVaildate;
use think\facade\Request;

class WechatPubInfo extends BaseController {
    public function getWechatPubInfoByShopNo(Request $request){
        (new ShopNoVaildate())->requestCheck();
        $companyWechatPub = WechatPubInfoService::getCompanyWechatPub($request::get('shopNo'));
        if (empty($companyWechatPub)) {
            $this->ok();
        }
        $wechatPubInfo = WechatPubInfoService::getWechatPubInfo($companyWechatPub->WechatPubInfoID);
        $this->ok($wechatPubInfo);
    }

}