<?php
namespace app\api\model;

use think\Model;

class ShuiWu extends Model {

    public static function getShuiWuById($where) {
        $content = self::where($where)->select();
        return $content;
    }

    public static function saveShuiWu($param) {
        $res = self::create($param);
        return $res;
    }

    public static function editShuiWu($param) {
        $res = self::where('id', $param['id'])->update($param);
        return $res;
    }

    public static function getShuiWuByPage($page) {
    	// * 分页查询
    	// * @param int|array $listRows 每页数量 数组表示配置参数
    	// * @param int|bool  $simple   是否简洁模式或者总记录数
    	// * @param array     $config   配置参数
    	// *                            page:当前页,
    	// *                            path:url路径,
    	// *                            query:url额外参数,
    	// *                            fragment:url锚点,
    	// *                            var_page:分页变量,
    	// *                            list_rows:每页数量
    	// *                            type:分页类名
    	$config['page'] = $page;
        $res = self::paginate(10, false, $config);
        return $res;
    }

    public static function deleteShuiWuById($id) {
        $res = self::where('id', $id)->delete();
        return $res;
    }

}
