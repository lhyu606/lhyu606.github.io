<?php
namespace app\api\model;

use think\Model;

class QrContent extends Model {

    public static function getQrContentById($where) {
        $content = self::where($where)->select();
        return $content;
    }

    public static function saveQrContent($param) {
        $res = self::create($param);
        return $res;
    }

}
