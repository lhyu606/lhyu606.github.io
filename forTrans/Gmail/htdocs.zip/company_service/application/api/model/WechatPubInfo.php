<?php
namespace app\api\model;

use think\Model;

class WechatPubInfo extends Model {
    protected $table = 'yj_tbl_wechatpubinfo';
}