<?php
namespace app\api\model;

use think\Model;

class CompanyWechatPub extends Model {
    protected $table = 'yj_tbl_companywechatpub';

}
