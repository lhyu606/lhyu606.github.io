<?php
namespace app\api\model;

use think\Model;

class Company extends Model {

    public static function getCompanyList($where) {
        $companyList = self::where($where)->select();
        return $companyList;

    }

    public static function getCompanyInfoByShopNo($shopNo) {
        $companyInfo = self::field('CompanyID, CompanyCode, CompanyName, CompanyAddress, LogoUrl, MapPositionX, MapPositionY')
            ->where('CompanyID', '=', $shopNo)
            ->where('CompanyStatus', '=', 0)
            ->find();
        return $companyInfo;
    }



}