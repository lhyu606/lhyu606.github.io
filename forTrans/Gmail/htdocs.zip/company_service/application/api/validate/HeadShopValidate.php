<?php
namespace app\api\validate;

class HeadShopValidate extends BaseValidate {
    protected $rule = [
        'headShopNo' => 'require|isPositiveInteger',
    ];

}