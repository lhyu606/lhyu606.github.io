<?php
namespace app\api\validate;

use app\lib\exception\ApiException;
use think\facade\Request;
use think\Validate;

class BaseValidate extends Validate {
    public function requestCheck()
    {
        $params = Request::param();
        if (!$this->check($params)) {
            print_r($this->check($params));
            $exception = new ApiException(
                [
                    'msg' => is_array($this->error) ? implode(
                        ';', $this->error) : $this->error,
                ]);
            throw $exception;
        }
        return true;
    }

    protected function isPositiveInteger($value, $rule='', $data='', $field='')
    {
        if (is_numeric($value) && is_int($value + 0) && ($value + 0) > 0) {
            return true;
        }
        return $field . '必须是正整数';
    }

    protected function isNotEmpty($value, $rule='', $data='', $field='')
    {
        if (empty($value)) {
            return $field . '不允许为空';
        } else {
            return true;
        }
    }
}