<?php
namespace app\api\validate;

class RegionCodeVaildate extends BaseValidate {
    protected $rule = [
        'regionCode' => 'require|isNotEmpty',
    ];

}