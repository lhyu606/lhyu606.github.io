<?php
namespace app\api\validate;

class ShopNameValidate extends BaseValidate {
    protected $rule = [
        'companyName' => 'require|isNotEmpty',
    ];

}