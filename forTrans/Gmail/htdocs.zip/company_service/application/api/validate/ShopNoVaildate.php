<?php
namespace app\api\validate;

class ShopNoVaildate extends BaseValidate {
    protected $rule = [
        'shopNo' => 'require|isPositiveInteger',
    ];

}