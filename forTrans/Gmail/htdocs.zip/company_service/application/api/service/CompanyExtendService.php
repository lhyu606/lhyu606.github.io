<?php
namespace app\api\service;

use app\api\model\CompanyExtend;
use think\facade\Cache;

class CompanyExtendService {
    public static function getExtendByShopNo($shopNo) {
        $extendInfo = Cache::get('company_extend:companyid_'.$shopNo);
        if (empty($extendInfo)) {
            $extendInfo = CompanyExtend::where('CompanyId', '=', $shopNo)->find();
            Cache::set('company_extend:companyid_'.$shopNo, $extendInfo);
        }

        return $extendInfo;
    }
}