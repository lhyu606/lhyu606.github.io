<?php
namespace app\api\service;

use app\api\model\BaoBei;
use app\api\model\ShuiWu;

class ReportService {

    /**
     * 保存报备信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function saveBaoBei($param) {
        $BaoBei = BaoBei::saveBaoBei($param);
        return $BaoBei;
    }
    /**
     * 保存报备信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function editBaoBei($param) {
        $BaoBei = BaoBei::editBaoBei($param);
        return $BaoBei;
    }
    /**
     * 根据 id 获取报备信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function getBaoBeiById($id) {
        $param = [
            ['id', '=', $id]
        ];
        $BaoBei = BaoBei::getBaoBeiById($param);
        return $BaoBei;
    }
    /**
     * 获取所有报备信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function getBaoBeiByPage($page) {
        $BaoBei = BaoBei::getBaoBeiByPage($page);
        return $BaoBei;
    }
    /**
     * 删除 指定 id 报备信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function deleteBaoBeiById($id) {
        $result = BaoBei::deleteBaoBeiById($id);
        return $result;
    }

    /**
     * 保存税务信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function saveShuiWu($param) {
        $ShuiWu = ShuiWu::saveShuiWu($param);
        return $ShuiWu;
    }
    /**
     * 保存税务信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function editShuiWu($param) {
        $ShuiWu = ShuiWu::editShuiWu($param);
        return $ShuiWu;
    }
    /**
     * 根据 id 获取税务信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function getShuiWuById($id) {
        $param = [
            ['id', '=', $id]
        ];
        $ShuiWu = ShuiWu::getShuiWuById($param);
        return $ShuiWu;
    }
    /**
     * 获取所有税务信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function getShuiWuByPage($page) {
        $ShuiWu = ShuiWu::getShuiWuByPage($page);
        return $ShuiWu;
    }
    /**
     * 删除 指定 id 税务信息
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function deleteShuiWuById($id) {
        $result = ShuiWu::deleteShuiWuById($id);
        return $result;
    }
}
