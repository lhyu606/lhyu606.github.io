<?php
namespace app\api\service;

use app\api\model\CompanyExtend;
use app\api\model\Company;
use think\facade\Cache;

class CompanyService {

    /**
     * @param $headShopNo 商家总店号
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function getCompanyListByHeadShopNo($headShopNo) {
        $param = [
            ['officeid', '=', $headShopNo],
            ['CompanyStatus', '=', 0],
        ];
        $companyList = Cache::get('companyList:officeid_'.$headShopNo);
        if (empty($companyList)) {
            $companyList = Company::getCompanyList($param);
            Cache::set('companyList:officeid_'.$headShopNo, $companyList);
        }
        return $companyList;
    }

    /**
     * @param $companyName
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function getCompanyListByShopName($companyName) {
        $param = [
            ['CompanyName', 'like', '%'.$companyName.'%'],
            ['CompanyStatus', '=', 0],
        ];
        $companyList = Cache::get('companyList:companyName_'.$companyName);
        if (empty($companyList)) {
            $companyList = Company::getCompanyList($param);
            Cache::set('companyList:companyName_'.$companyName, $companyList);
        }
        return $companyList;
    }

    /**
     * @param $regionCode
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function getCompanyListByRegionCode($regionCode) {
        $param = [
            ['RegionCode', 'like', $regionCode.'%'],
            ['CompanyStatus', '=', 0],
        ];
        $companyList = Cache::get('companyList:regionCode_'.$regionCode);
        if (empty($companyList)) {
            $companyList = Company::getCompanyList($param);
            Cache::set('companyList:regionCode_'.$regionCode, $companyList);
        }
        return $companyList;
    }


    /**
     * @param $companyList
     * @return array
     */
    public static function putCompany($companyList) {

        $dataArray = array();
        foreach ($companyList as $key => $company) {
            //判断是否开启电子会员
            $openEcard = self::isOpenEcard($company->CompanyID);
            //未开通
            if ($openEcard == 1) {
                unset($companyList[$key]);
                continue;
            }
            $data = array(
                'companyid' => $company->CompanyID,
                'companyname' => $company->CompanyName,
                'companyaddress' => $company->CompanyAddress,
                'logourl' => $company->LogoUrl,
                'lon' => $company->MapPositionX,
                'lat' => $company->MapPositionY,
            );

            array_push($dataArray, $data);
        }
        return $dataArray;
    }

    /**
     * @param $shopNo
     * @return int
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public static function isOpenEcard($shopNo) {
        $companyExtend = CompanyExtendService::getExtendByShopNo($shopNo);

        if (!$companyExtend) {
            return 1;
        }
        return $companyExtend->IsOpenEcard == 0 ? 0 : 1;
    }


    public static function getCompanyInfo($shopNo) {
        $companyInfo = Cache::get('company:companyid_'.$shopNo);
        if (empty($companyInfo)) {
            $companyInfo = Company::getCompanyInfoByShopNo($shopNo);
            Cache::set('company:companyid_'.$shopNo, $companyInfo);
        }
        return $companyInfo;
    }



}