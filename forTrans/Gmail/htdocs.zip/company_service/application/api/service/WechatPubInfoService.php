<?php
namespace app\api\service;

use app\api\model\CompanyWechatPub;
use app\api\model\WechatPubInfo;
use think\facade\Cache;

class WechatPubInfoService {

    /**
     * @param $shopNo
     * @return array|\PDOStatement|string|\think\Model|null
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public static function getCompanyWechatPub($shopNo){
        $companyWechatPub = Cache::get('companywechatpub:companyid_'.$shopNo);
        if (empty($companyWechatPub)) {
            $companyWechatPub = CompanyWechatPub::field('WechatPubInfoID')
                ->where('CompanyID', '=', $shopNo)
                ->find();
            Cache::set('companywechatpub:companyid_'.$shopNo, $companyWechatPub);
        }

        return $companyWechatPub;
    }

    public static function getWechatPubInfo($wechatPubInfoId) {
        $wechatPubInfo = Cache::get('wechatpubinfo:wechatPubInfoId_'.$wechatPubInfoId);
        if (empty($wechatPubInfo)) {
            $wechatPubInfo = WechatPubInfo::where('WechatPubInfoID', '=', $wechatPubInfoId)->find();
            Cache::set('wechatpubinfo:wechatPubInfoId_'.$wechatPubInfoId, $wechatPubInfo);
        }
        return $wechatPubInfo;

    }

}
