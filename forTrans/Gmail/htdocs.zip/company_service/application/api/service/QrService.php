<?php
namespace app\api\service;

use app\api\model\QrContent;

class QrService {

    /**
     * @param $headShopNo 商家总店号
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function saveQrContent($param) {
        $QrContent = QrContent::saveQrContent($param);
        return $QrContent;
    }
    /**
     * @param $headShopNo 商家总店号
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function getQrContentById($id) {
        $param = [
            ['qrId', '=', $id]
        ];
        $QrContent = QrContent::getQrContentById($param);
        return $QrContent;
    }
}
