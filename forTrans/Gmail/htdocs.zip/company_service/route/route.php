<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, X-Requested-With');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE');
header('Access-Control-Max-Age: 1728000');


Route::get('think', function () {
    return 'hello,ThinkPHP5!';
});


Route::get('hello/:name', 'api/index/hello');

Route::post('api/saveBaoBei', 'api/report/saveBaoBei');
Route::post('api/getBaoBei', 'api/report/getBaoBei');
Route::post('api/allBaoBei', 'api/report/getBaoBeiByPage');
Route::post('api/editBaoBei', 'api/report/editBaoBei');
Route::post('api/deleteBaoBei', 'api/report/deleteBaoBeiById');

Route::post('api/saveShuiWu', 'api/report/saveShuiWu');
Route::post('api/getShuiWu', 'api/report/getShuiWu');
Route::post('api/allShuiWu', 'api/report/getShuiWuByPage');
Route::post('api/editShuiWu', 'api/report/editShuiWu');
Route::post('api/deleteShuiWu', 'api/report/deleteShuiWuById');

return [

];
